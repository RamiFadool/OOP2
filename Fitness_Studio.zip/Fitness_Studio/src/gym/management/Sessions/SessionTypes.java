package gym.management.Sessions;

public class SessionTypes {
    public static final String Pilates = "Pilates";
    public static final String ThaiBoxing = "ThaiBoxing";
    public static final String MachinePilates = "MachinePilates";
    public static final String Ninja = "Ninja";

}