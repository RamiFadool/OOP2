package gym.management.Sessions;

import gym.customers.*;

public class SessionFactory {
    public static Session createSession(String sessionType, String dateAndTime, String forumType, Instructor instructor) {
        switch (sessionType) {
            case SessionTypes.Pilates:
                return new Pilates(dateAndTime, forumType, instructor);
            case SessionTypes.ThaiBoxing:
                return new ThaiBoxing(dateAndTime, forumType, instructor);
            case SessionTypes.MachinePilates:
                return new MachinePilates(dateAndTime, forumType, instructor);
            case SessionTypes.Ninja:
                return new Ninja(dateAndTime, forumType, instructor);
            default:
                throw new IllegalArgumentException("Invalid session type: " + sessionType);
        }
    }
}

