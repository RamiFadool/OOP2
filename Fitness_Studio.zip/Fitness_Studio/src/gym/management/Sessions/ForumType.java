package gym.management.Sessions;

public class ForumType{
    public static final String All = "All";
    public static final String Male = "Male";
    public static final String Female = "Female";
    public static final String Seniors = "Seniors";
}
