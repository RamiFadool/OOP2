package gym.management.Sessions;

import gym.customers.*;

import java.util.ArrayList;

public class MachinePilates implements Session {
    private String dateAndTime;
    private String forumType;
    private Instructor instructor;
    private ArrayList<Person> registeredClients;

    public MachinePilates(String dateAndTime, String forumType, Instructor instructor) {
        this.dateAndTime = dateAndTime;
        this.forumType = forumType;
        this.instructor = instructor;
        this.registeredClients = new ArrayList<>();
    }

    @Override
    public String getSessionType() {
        return SessionTypes.MachinePilates;
    }

    @Override
    public String getDateAndTime() {
        return dateAndTime;
    }

    @Override
    public String getForumType() {
        return forumType;
    }

    @Override
    public Instructor getInstructor() {
        return instructor;
    }

    @Override
    public ArrayList<Person> getRegisteredClients() {
        return registeredClients;
    }

    @Override
    public int getPrice() {
        return 80;
    }

    @Override
    public int getMaxParticipants() {
        return 10;
    }

    @Override
    public String toString() {
        return "Session Type: " + getSessionType() +
                " | Date: " + getDateAndTime() +
                " | Forum: " + getForumType() +
                " | Instructor: " + getInstructor().getName() +
                " | Participants: " + getRegisteredClients().size() + "/" + getMaxParticipants();
    }
}
