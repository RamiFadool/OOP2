package gym.management.Sessions;

import gym.customers.*;
import java.util.ArrayList;

public interface Session {
    String getSessionType();
    String getDateAndTime();
    String getForumType();
    Instructor getInstructor();
    ArrayList<Person> getRegisteredClients();
    int getPrice();
    int getMaxParticipants();
    String toString();
}
