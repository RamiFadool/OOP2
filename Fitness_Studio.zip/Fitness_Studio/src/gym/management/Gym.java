package gym.management;

import gym.customers.Client;
import gym.customers.Instructor;
import gym.customers.Person;
import gym.management.Sessions.Session;

public class Gym {
    private static final Gym instance = new Gym();
    private String gymName;
    private Secretary secretary;
    private int gymBalance = -9000;

    private Gym(){}

    public static Gym getInstance(){
        return instance;
    }

    public void setName(String gymName){
        this.gymName = gymName;
    }

    public void setSecretary(Person p, int salary){
        if (this.secretary == null) {
            this.secretary = new Secretary(p);
            this.secretary.setSalary(salary);
            this.secretary.addAction("A new secretary has started working at the gym: " + p.getName());
        } else {
            Secretary newSecretary = new Secretary(p);
            newSecretary.setSalary(salary);
            newSecretary.getClients().addAll(this.secretary.getClients());
            newSecretary.getInstructors().addAll(this.secretary.getInstructors());
            newSecretary.getSessions().addAll(this.secretary.getSessions());
            newSecretary.getActionsHistory().addAll(this.secretary.getActionsHistory());
            this.secretary.setSecretary(false);
            this.secretary = newSecretary;
            newSecretary.addAction("A new secretary has started working at the gym: " + p.getName());

        }
    }

    public int getGymBalance(){
        return gymBalance;
    }

    public void setGymBalance(int balance){
        this.gymBalance = balance;
    }

    public Secretary getSecretary() {
        return secretary;
    }

    @Override
    public String toString(){
        StringBuilder information = new StringBuilder();

        information.append("Gym Name: " + gymName + "\n");
        information.append("Gym Secretary: " + secretary + "\n");
        information.append("Gym Balance: " + gymBalance + "\n");

        information.append("\nClients Data:\n");
        for(Client client : secretary.getClients()){
            information.append(client +  "\n");
        }

        information.append("\nEmployees Data:\n");
        for(Instructor instructor : secretary.getInstructors()){
            information.append(instructor + "\n");
        }
        information.append(secretary + "\n");

        information.append("\nSessions Data:");
        for(Session session : secretary.getSessions()){
            information.append("\n" + session);
        }

        return information.toString();
    }
}
