package gym.Exception;

public class ClientNotRegisteredException extends Exception{
    public ClientNotRegisteredException(String message){
        super(message);
    }
}
