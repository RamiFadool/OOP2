package gym.customers;

public class Gender {
    public static final String Male = "Male";
    public static final String Female = "Female";

}
