package gym.customers;

import gym.management.Sessions.SessionTypes;

import java.util.ArrayList;

public class Instructor extends Person{
    private Person instructor;
    private int salaryPerHour;
    private ArrayList<String> qualifiedSessions;

    public Instructor(Person p, int salaryPerHour, ArrayList<String> qualifiedSessions) {
        super(p.getID(), p.getName(), p.getBalance(), p.getGender(), p.getBirthDate());
        this.salaryPerHour = salaryPerHour;
        this.qualifiedSessions = qualifiedSessions;
        instructor = p;
    }

    public int getSalaryPerHour(){
        return salaryPerHour;
    }

    public ArrayList<String> getQualifiedSessions(){
        return qualifiedSessions;
    }

    @Override
    public int getBalance(){
        return instructor.getBalance();
    }

    @Override
    public void setBalance(int balance){
        this.instructor.balance = balance;
    }

    public String certifiedClasses() {
        return String.join(", ", qualifiedSessions);
    }

    @Override
    public String toString() {
        return "ID: " + getID() + " | Name: " + getName() + " | Gender: " + getGender()
                + " | Birthday: " + getBirthDate() + " | Age: " + age()
                + " | Balance: " + getBalance() + " | Role: Instructor"
                + " | Salary per Hour: " + salaryPerHour
                + " | Certified Classes: " + certifiedClasses();
    }


}
