package gym.customers;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Person implements Observer{
    private static int idCounter = 1111;
    private int id;
    private String gender;
    private String name;
    protected int balance;
    private String birthDate;
    private ArrayList<String> notifications = new ArrayList<>();

    public Person(String name, int balance, String gender, String birthDate){
        this.id = idCounter++;
        this.name = name;
        this.balance = balance;
        this.gender = gender;
        this.birthDate = birthDate;
    }

    public Person(int existingId, String name, int balance, String gender, String birthDate) {
        this.id = existingId;
        this.name = name;
        this.balance = balance;
        this.gender = gender;
        this.birthDate = birthDate;
    }

    public int getID(){
        return id;
    }

    public String getName(){
        return name;
    }

    public int getBalance(){
        return balance;
    }

    public void setBalance(int balance){
        this.balance = balance;
    }

    public String getGender(){
        return gender;
    }
    public String getBirthDate(){
        return birthDate;
    }

    public int age(){
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate dateOfBirth = LocalDate.parse(getBirthDate(), formatter);
        int age = Period.between(dateOfBirth, currentDate).getYears();

        if (currentDate.isBefore(dateOfBirth.withYear(currentDate.getYear()))) {
            age++;
        }

        return age;
    }
    @Override
    public void update(String message) {
        notifications.add(message);
    }

    public ArrayList<String> getNotifications() {
        return notifications;
    }
}
