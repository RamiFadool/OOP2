package gym.customers;

public interface Observer {
    void update(String message);
}
