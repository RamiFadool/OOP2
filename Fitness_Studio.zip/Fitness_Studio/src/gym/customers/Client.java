package gym.customers;

import java.util.ArrayList;
import java.util.Objects;

public class Client extends Person implements Observer{
    private Person client;
    private ArrayList<String> notifications = new ArrayList<>();


    public Client(Person p){
        super(p.getID(), p.getName(), p.getBalance(), p.getGender(), p.getBirthDate());
        this.client = p;
    }

    public ArrayList<String> getNotifications() {
        return notifications;
    }

    @Override
    public void update(String message) {
        notifications.add(message);
    }

    @Override
    public int getBalance(){
        return client.getBalance();
    }

    @Override
    public void setBalance(int balance){
        this.client.balance = balance;
    }



    @Override
    public String toString() {
        return "ID: " + getID() + " | Name: " + getName() + " | Gender: " + getGender()
                + " | Birthday: " + getBirthDate() + " | Age: " + age()
                + " | Balance: " + getBalance();
    }

}

